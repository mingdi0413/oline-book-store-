const couponRouter = require("./couponController.js");
module.exports = couponRouter;
