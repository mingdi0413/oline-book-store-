const adminRouter = require("./adminController");
module.exports = adminRouter;
