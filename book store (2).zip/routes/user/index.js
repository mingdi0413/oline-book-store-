const userRouter = require("./userController");
module.exports = userRouter;
